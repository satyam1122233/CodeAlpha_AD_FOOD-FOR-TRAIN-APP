package com.satyam.foodfortrainapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class BillActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);

        ArrayList<String> selectedItems = getIntent().getStringArrayListExtra("selectedItems");
        ArrayList<String> selectedPrices = getIntent().getStringArrayListExtra("selectedPrices"); // Add this line

        TextView selectedItemsTextView = findViewById(R.id.selectedItemsTextView);
        TextView billPrize = findViewById(R.id.billPrize);

        TextView totalPrize = findViewById(R.id.totalPrize);
        int totalBil=0;

        StringBuilder itemsText = new StringBuilder();
        StringBuilder pricesText = new StringBuilder(); // Add this line
        for (int i = 0; i < selectedItems.size(); i++) {
            itemsText.append(selectedItems.get(i)).append("\n");
            selectedItemsTextView.setText(itemsText.toString());

            pricesText.append("Rs.").append(selectedPrices.get(i)).append("\n");
            billPrize.setText( pricesText.toString());

            totalBil+=Integer.parseInt(selectedPrices.get(i));

        }

        totalPrize.setText("Total Amount: Rs." + totalBil);



    }
}