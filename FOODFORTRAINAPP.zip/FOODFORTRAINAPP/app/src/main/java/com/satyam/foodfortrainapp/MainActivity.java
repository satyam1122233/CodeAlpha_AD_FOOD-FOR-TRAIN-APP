package com.satyam.foodfortrainapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText pnrTxt;
    Button btnNext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pnrTxt=findViewById(R.id.pnrTxt);
        btnNext=findViewById(R.id.btnNext);

        btnNext.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (pnrTxt.getText().toString().length()==10&&pnrTxt.getText().toString().matches(("\\d+"))){
                    {
                        String txt=pnrTxt.getText().toString();
                        if(!txt.isEmpty()){
                            Intent intent = new Intent(MainActivity.this, FoodProducts.class);
                            intent.putExtra("pnrNo",txt);
                            startActivity(intent);

                        }else {
                            Toast.makeText(MainActivity.this, "Please Enter PNR Number", Toast.LENGTH_SHORT).show();
                        }
                    }

                }else {

                    Toast.makeText(MainActivity.this, "Please Enter Valid PNR Number", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}