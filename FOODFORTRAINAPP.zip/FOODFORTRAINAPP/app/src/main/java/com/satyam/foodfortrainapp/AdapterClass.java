package com.satyam.foodfortrainapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterClass extends RecyclerView.Adapter<AdapterClass.ViewHolder>  {

Context context;
ArrayList<ModelClass>arrayList=new ArrayList<>();

    ArrayList<String>billArray=new ArrayList<>();
    ArrayList<String>prizeArray=new ArrayList<>();

    private OnAdapterItemListener onAdapterItemListener; // Add this line

    public void setOnAdapterItemListener(OnAdapterItemListener listener) { // Add this method
        this.onAdapterItemListener = listener;
    }


AdapterClass(Context context,ArrayList<ModelClass>arrayList){
    this.context=context;
    this.arrayList=arrayList;

}
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(context).inflate(R.layout.fooditems,parent,false);

        ViewHolder  viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
    holder.foodImg.setImageResource(arrayList.get(position).img);
    holder.foodNameTxt.setText(arrayList.get(position).foodNameTxt);
    holder.foodDescriptionTxt.setText(arrayList.get(position).foodDescriptionTxt);
    holder.prizeTxt.setText(arrayList.get(position).prizeTxt);
        holder.rs.setText(arrayList.get(position).rs);

        holder.btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(context)
                        .setTitle("Add Item")
                        .setMessage("Are you sure you want to add this item?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                {

                                    billArray.add( arrayList.get(position).foodNameTxt);
                                    prizeArray.add( arrayList.get(position).prizeTxt);


                                    onAdapterItemListener.onItemAdded(billArray);
                                    onAdapterItemListener.onItemAdded2(prizeArray);




                                }
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Do nothing if "No" is clicked
                            }
                        });

                alertDialog.show();
            }
        });
    }



    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

    TextView foodNameTxt,foodDescriptionTxt,prizeTxt,rs;
        Button btnAddItem;

        ImageView foodImg;
        CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

        foodNameTxt=itemView.findViewById(R.id.foodNameTxt);
        foodDescriptionTxt=itemView.findViewById(R.id.foodDescriptionTxt);
        prizeTxt=itemView.findViewById(R.id.prizeTxt);
        btnAddItem=itemView.findViewById(R.id.btnAddItem);
        foodImg=itemView.findViewById(R.id.foodImg);
            rs=itemView.findViewById(R.id.rs);
            cardView=itemView.findViewById(R.id.cardView);
        }


    }
    public interface OnAdapterItemListener {
        void onItemAdded(ArrayList<String> billArray);

        void onItemAdded2(ArrayList<String> billArray);
    }


}
