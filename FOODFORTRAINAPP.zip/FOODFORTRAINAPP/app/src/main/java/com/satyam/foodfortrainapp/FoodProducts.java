package com.satyam.foodfortrainapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FoodProducts extends AppCompatActivity {

    ArrayList<ModelClass> arrayList=new ArrayList<>();
    ArrayList<String> selectedItems = new ArrayList<>(); // Add this line
    ArrayList<String> selectedPrices = new ArrayList<>(); // Add this line

    RecyclerView recyclerView;
    String pnrNoTxt;
    TextView pnrView;

  Button proceedBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_products);

        pnrView=findViewById(R.id.pnrView);
        pnrNoTxt=getIntent().getStringExtra("pnrNo");
        pnrView.setText("PNR Number : "+pnrNoTxt);

        proceedBtn=findViewById(R.id.proceedBtn);

        recyclerView=findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



        arrayList.add(new ModelClass(R.drawable.burger  ,"Burger Blast","Burger, Fast Food, Beverages","250","Rs."));
        arrayList.add(new ModelClass(R.drawable.pizza,"Pizza Bite","Pizza, Fast Food, Desserts, Beverages","150","Rs."));
        arrayList.add(new ModelClass(R.drawable.paneerbhujji,"Paneer Bhurji Bread Scramble","Paneer Bhurji a top bread, a delightful breakfast scramble","299","Rs."));
        arrayList.add(new ModelClass(R.drawable.thali  ,"Indian Thali","Dal Tadka, Bhindi Sabzi, Rajma Masala, Soya Chaap, Chapati, Rice","349","Rs."));
        arrayList.add(new ModelClass(R.drawable.pavbhaji,"Amul Butter Pav Bhaji","Pav bhaji a spicy curry of mixed vegetables bhaji cooked in a special blend of spices","160","Rs."));
        arrayList.add(new ModelClass(R.drawable.sandwitxh,"Natural Badam Sandwich","Delicious layered snack made with bread and fillings","99","Rs."));

        AdapterClass adapter =new AdapterClass(this,arrayList);
    //    AdapterClass adapter = new AdapterClass(this, arrayList, selectedItems); // Pass selectedItems to the adapter



        adapter.setOnAdapterItemListener(new AdapterClass.OnAdapterItemListener() {
            @Override
            public void onItemAdded(ArrayList<String> billArray) {
               selectedItems.removeAll(billArray);
                selectedItems.addAll(billArray);

            }

            @Override
            public void onItemAdded2(ArrayList<String> prizeArray) {
                selectedPrices.removeAll(prizeArray);

                selectedPrices.addAll(prizeArray);
            }
        });





        recyclerView.setAdapter(adapter);

        proceedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FoodProducts.this, BillActivity.class);
                intent.putStringArrayListExtra("selectedItems", selectedItems);
                intent.putStringArrayListExtra("selectedPrices", selectedPrices); // Add this line
                startActivity(intent);
            }
        });




    }




}