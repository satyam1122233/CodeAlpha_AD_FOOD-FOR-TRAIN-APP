package com.satyam.foodfortrainapp;

public class ModelClass {

    int img;
    String foodNameTxt,foodDescriptionTxt,prizeTxt,rs;

    public ModelClass(int img,String foodNameTxt,String foodDescriptionTxt,String prizeTxt,String rs){
        this.img=img;
        this.foodNameTxt=foodNameTxt;
        this.foodDescriptionTxt=foodDescriptionTxt;
        this.prizeTxt=prizeTxt;
        this.rs=rs;


    }
}
